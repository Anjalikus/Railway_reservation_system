-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 24, 2022 at 10:28 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `booking`
--

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE `tickets` (
  `pnr` int(10) NOT NULL,
  `t_status` varchar(25) NOT NULL,
  `source station` varchar(30) NOT NULL,
  `destination station` varchar(25) NOT NULL,
  `journey date` date NOT NULL,
  `class` varchar(10) NOT NULL,
  `dt` timestamp(5) NOT NULL DEFAULT current_timestamp(5) ON UPDATE current_timestamp(5),
  `people` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tickets`
--

INSERT INTO `tickets` (`pnr`, `t_status`, `source station`, `destination station`, `journey date`, `class`, `dt`, `people`) VALUES
(72103641, 'Confirm', 'New Delhi', 'Jammu', '2022-06-23', 'First Clas', '0000-00-00 00:00:00.00000', 4),
(72103646, 'Waiting', 'PRAYAGRAJ JN', 'Jammu', '2022-07-10', '2s', '2022-06-23 15:19:39.91392', 0),
(72103647, 'Waiting', 'NEW DELHI', 'Jammu', '2022-06-28', '2s', '2022-06-24 08:14:50.85612', 0),
(72103710, 'Confirm', 'Prayagraj Jn', 'New Delhi', '2022-06-29', '3A', '0000-00-00 00:00:00.00000', 8),
(72103784, 'Confirm', 'Jammu', 'Chennai Central', '2022-06-21', '2A', '0000-00-00 00:00:00.00000', 5),
(721037115, 'Confirm', 'Mumbai Central', 'New Delhi', '2022-06-30', 'First Clas', '0000-00-00 00:00:00.00000', 7);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`pnr`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tickets`
--
ALTER TABLE `tickets`
  MODIFY `pnr` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=721037116;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
