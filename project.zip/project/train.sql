-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 24, 2022 at 10:27 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `train`
--

-- --------------------------------------------------------

--
-- Table structure for table `train_names`
--

CREATE TABLE `train_names` (
  `Train No` int(5) NOT NULL,
  `Train Name` varchar(25) NOT NULL,
  `Source` varchar(20) NOT NULL,
  `Destination` varchar(20) NOT NULL,
  `Departure` time NOT NULL,
  `Arrival` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `train_names`
--

INSERT INTO `train_names` (`Train No`, `Train Name`, `Source`, `Destination`, `Departure`, `Arrival`) VALUES
(12951, 'Rajdhani Express', 'Mumbai Central', 'New Delhi', '17:00:00', '08:32:00'),
(19019, 'Haridwar Express', 'Mumbai Central', 'New Delhi', '00:05:00', '02:30:00'),
(22178, 'Mahanagri Express', 'Mumbai Central', 'Prayagraj Jn', '13:05:00', '11:40:00'),
(22919, 'Humsafar Express', 'Mumbai Central', 'Chennai Central', '15:50:00', '13:22:00'),
(12471, 'Swaraj Express', 'Mumbai Central', 'Jammu ', '11:00:00', '14:50:00'),
(22210, 'Duronto Express', 'New Delhi', 'Mumbai Central', '22:10:00', '15:50:00'),
(12270, 'Duronto Express', 'New Delhi', 'Chennai Central', '15:55:00', '20:50:00'),
(12425, 'Rajdhani Express', 'New Delhi', 'Jammu', '20:40:00', '05:00:00'),
(22177, 'Mahanagri Express', 'Prayagraj Jn', 'Mumbai Central', '08:50:00', '01:30:00'),
(22435, 'Vande Bharat', 'Prayagraj Jn', 'New Delhi', '00:05:00', '06:42:00'),
(12669, 'Ganga Kaveri Express', 'Prayagraj Jn', 'Chennai Central', '15:55:00', '09:50:00'),
(18309, 'Udham Express', 'Prayagraj Jn', 'Jammu', '09:55:00', '14:10:00'),
(22920, 'Humsafar Express', 'Chennai Central', 'Mumbai Central', '16:52:00', '02:30:00'),
(12271, 'Duronto Express', 'Chennai Central', 'New Delhi', '08:30:00', '18:55:00'),
(12668, 'Ganga Kaveri Express', 'Chennai Central', 'Prayagraj Jn', '00:58:00', '19:15:00'),
(16102, 'Kollam Express', 'Chennai Central', 'Jammu', '00:02:00', '23:58:00'),
(12472, 'Swaraj Express', 'Jammu', 'Mumbai Central', '11:35:00', '16:12:00'),
(12424, 'Rajdhani Express', 'Jammu', 'New Delhi', '05:23:00', '13:48:00'),
(18308, 'Udham Express', 'Jammu', 'Prayagraj Jn', '14:10:00', '19:36:00'),
(16101, 'Kollam Express', 'Jammu', 'Chennai Central', '02:28:00', '23:58:00'),
(22436, 'Vande Bharat', 'New Delhi', 'Prayagraj Jn', '06:00:00', '12:08:00');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
